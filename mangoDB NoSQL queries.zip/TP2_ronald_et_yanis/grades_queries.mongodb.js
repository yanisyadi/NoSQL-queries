/**
 * TP2: Exploitation of a json format dataset to answer some statistical questions with a total of 12 queries
 * Students: Yadi, Yanis Atmane && Gedeon, Ronald
 * Dataset grades Link: https://github.com/neelabalan/mongodb-sample-dataset/blob/main/sample_training/grades.json
 * Pre-requisits: upload the dataset to a newly created DB/collecion 'tp2db'/'rawgrades' using mongodb compass
 */

/* -- Query 1: Migrate tp2db/rawgrades to students/grades after modifying the schema
        - convert student_id from zero-based index to 1-based index by incrementing its value each time
        - score formatted .2f: using map & round in the aggregation pipeline
      & count the number of documents into the collection
*/
// use('students');
// db.dropDatabase();

use("tp2db");
db.rawgrades.aggregate([
  {
    $project: {
      student_id: { $add: ["$student_id", 1] },
      scores: {
        $map: {
          input: "$scores",
          as: "scoreItem",
          in: {
            type: "$$scoreItem.type",
            score: { $round: ["$$scoreItem.score", 2] },
          },
        },
      },
      class_id: 1,
    },
  },
  { $out: { db: "students", coll: "grades" } },
]);
use("students");
db.grades.find({}).count(); //100K

/** -- Query 2: Count the number of students */
use("students");
db.grades.distinct("student_id").length; //10K

/** -- Query 3: Top 10 students based on the avg score across all score types: exam, quiz & homework for each student */
use("students");
db.grades.aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: "$student_id",
      average_score: { $avg: "$scores.score" },
    },
  },
  {
    $project: {
      studentID: "$_id", //alias
      average_score: { $round: ["$average_score", 2] },
      _id: 0,
    },
  },
  { $sort: { average_score: -1 } },
  { $limit: 10 },
]);

/** -- Query 4: The min & max score for each type: exam, quiz, homework */
use("students");
db.grades.aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: "$scores.type",
      min_score: { $min: "$scores.score" },
      max_score: { $max: "$scores.score" },
    },
  },
  { $project: { score_type: "$_id", min_score: 1, max_score: 1, _id: 0 } },
  { $sort: { score_type: 1 } }, //sort by score_type which is an alias
]);

/*--Query 5: Average score per class */
use("students");
db.grades.aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: "$class_id",
      average_class_score: { $avg: "$scores.score" },
    },
  },
  {
    $project: {
      classID: "$_id", //alias
      average_score: { $round: ["$average_class_score", 2] },
      _id: 0,
    },
  },
  { $sort: { average_class_score: -1 } },
]);

/** --Query 6: Average Score for each student per test type */
use("students");
db.grades.aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: { student_id: "$student_id", test_type: "$scores.type" },
      average_score: { $avg: "$scores.score" },
    },
  },
  { $project: { _id: 1, average_score: { $round: ["$average_score", 2] } } },
  { $sort: { "_id.student_id": 1, "_id.test_type": 1 } },
]);

//-------------------
/* --Query 7: The number of students per class */
use("students");
db.grades.aggregate([
  {
    $group: {
      _id: "$class_id",
      totalStudentsInClass: { $sum: 1 },
    },
  },
  {
    $project: {
      classID: "$_id", //alias
      totalStudents: "$totalStudentsInClass",
      _id: 0,
    },
  },
]);

/*--Query 8: Students who have (homework or exam) < 50 and at least a quiz > 90 */
use("students");
db.getCollection("grades").find({
  $and: [
    {
      $or: [
        { scores: { $elemMatch: { type: "homework", score: { $lt: 50 } } } },
        { scores: { $elemMatch: { type: "exam", score: { $lt: 50 } } } },
      ],
    },
    {
      scores: { $elemMatch: { type: "quiz", score: { $gt: 90 } } },
    },
  ],
});

/*--Query 9:  Count the number of homework & quiz taken by each student */
use("students");
db.getCollection("grades").aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: { student_id: "$student_id", score_type: "$scores.type" },
      score_count: { $sum: 1 },
    },
  },
  {
    $group: {
      _id: "$_id.student_id",
      scores: {
        $push: {
          type: "$_id.score_type",
          count: "$score_count",
        },
      },
    },
  },
]);

/*--Query 10: Total score per student for each class */
use("students");
db.getCollection("grades").aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: { student_id: "$student_id", class_id: "$class_id" },
      totalScore: { $sum: "$scores.score" },
    },
  },
]);

/*--Query 11a: the overall average across all scores type. result = 49.91 */
use("students");
db.grades.aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: null,
      overall_avg_score: { $avg: "$scores.score" },
    },
  },
  {
    $project: {
      _id: 0,
      overall_avg_score: { $round: ["$overall_avg_score", 2] },
    },
  },
]);

/*--Query 11b: Students whose average < 49.91, i.e. the overall average across all scores type */
use("students");
db.grades.aggregate([
  { $unwind: "$scores" },
  {
    $group: {
      _id: "$student_id",
      AverageScore: { $avg: "$scores.score" },
    },
  },
  {
    $match: {
      AverageScore: { $lt: 49.91 },
    },
  },
  {
    $project: {
      studentID: "$_id",
      AverageScore: { $round: ["$AverageScore", 2] },
      _id: 0,
    },
  },
]);

/*--Query 12: grades join studentsInfo using lookup */
use("students");
db.getCollection("studentsInfo").insertMany([
  {
    student_id: 1,
    name: "Alice Johnson",
    age: 20,
    major: "Computer Science",
  },
  {
    student_id: 2,
    name: "Bob Smith",
    age: 21,
    major: "Mathematics",
  },
  {
    student_id: 3,
    name: "Carol Williams",
    age: 22,
    major: "Physics",
  },
  {
    student_id: 4,
    name: "David Brown",
    age: 20,
    major: "Chemistry",
  },
  {
    student_id: 5,
    name: "Eva Davis",
    age: 23,
    major: "Biology",
  },
]);

use("students");
db.getCollection("grades").aggregate([
  {
    $lookup: {
      from: "studentsInfo",
      localField: "student_id",
      foreignField: "student_id",
      as: "studentDetails",
    },
  },
  {
    $unwind: "$studentDetails",
  },
  {
    $project: {
      student_id: 1,
      class_id: 1,
      scores: 1,
      "studentDetails.name": 1,
      "studentDetails.age": 1,
      "studentDetails.major": 1,
      _id:0
    },
  },
]);
